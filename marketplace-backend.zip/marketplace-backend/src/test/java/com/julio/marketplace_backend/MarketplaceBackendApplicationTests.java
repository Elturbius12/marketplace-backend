package com.julio.marketplace_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketplaceBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
